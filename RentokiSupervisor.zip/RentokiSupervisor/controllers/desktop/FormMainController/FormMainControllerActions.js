define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0a6e2f1747e4943 **/
    AS_Button_g9b3d57b1650461daef55cc745fca82c: function AS_Button_g9b3d57b1650461daef55cc745fca82c(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("SupervisorForm");
        ntf.navigate({
            "Button0a6e2f1747e4943_text": self.view.Button0a6e2f1747e4943.text,
            "_meta_": {
                "eventName": "onClick",
                "widgetId": "Button0a6e2f1747e4943"
            }
        });
    }
});