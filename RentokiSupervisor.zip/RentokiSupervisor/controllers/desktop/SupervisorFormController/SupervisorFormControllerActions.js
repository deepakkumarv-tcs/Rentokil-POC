define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Assign **/
    AS_Button_d909d0d277174c46836dd63af40cf0ef: function AS_Button_d909d0d277174c46836dd63af40cf0ef(eventobject) {
        var self = this;

        function SHOW_ALERT_h1587c057864416d8c4789b55207f13c_True() {}

        function SHOW_ALERT_h1587c057864416d8c4789b55207f13c_False() {}

        function SHOW_ALERT_h1587c057864416d8c4789b55207f13c_Callback(response) {
            if (response === true) {
                SHOW_ALERT_h1587c057864416d8c4789b55207f13c_True();
            } else {
                SHOW_ALERT_h1587c057864416d8c4789b55207f13c_False();
            }
        }
        voltmx.ui.Alert({
            "alertType": constants.ALERT_TYPE_CONFIRMATION,
            "alertTitle": "Assigned ",
            "yesLabel": "Yes",
            "noLabel": "No",
            "alertIcon": null,
            "message": "Assigned to New",
            "alertHandler": SHOW_ALERT_h1587c057864416d8c4789b55207f13c_Callback
        }, {
            "iconPosition": constants.ALERT_ICON_POSITION_LEFT
        });
    },
    /** onMapping defined for SupervisorForm **/
    AS_Form_g38dbfbfb6d641e5a834dec21e2def3c: function AS_Form_g38dbfbfb6d641e5a834dec21e2def3c(eventobject) {
        var self = this;

        function SHOW_ALERT_g4120ee48d04443fada0e072bcee9f8d_True() {}

        function INVOKE_ASYNC_SERVICE_c93fd5a3c4234a309691bbc2d8360545_Callback(status, rentokil_db_service_request_trx_get) {
            voltmx.application.dismissLoadingScreen();
            if (rentokil_db_service_request_trx_get.opstatus == 0) {} else {
                function SHOW_ALERT_g4120ee48d04443fada0e072bcee9f8d_Callback() {
                    SHOW_ALERT_g4120ee48d04443fada0e072bcee9f8d_True();
                }
                voltmx.ui.Alert({
                    "alertType": constants.ALERT_TYPE_INFO,
                    "alertTitle": null,
                    "yesLabel": null,
                    "noLabel": null,
                    "alertIcon": null,
                    "message": "Data fetch failed! Please try again later.",
                    "alertHandler": SHOW_ALERT_g4120ee48d04443fada0e072bcee9f8d_Callback
                }, {
                    "iconPosition": constants.ALERT_ICON_POSITION_LEFT
                });
            }
        }
        voltmx.application.showLoadingScreen(null, null, constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
        if (rentokil_db_service_request_trx_get_inputparam == undefined) {
            var rentokil_db_service_request_trx_get_inputparam = {};
        }
        rentokil_db_service_request_trx_get_inputparam["serviceID"] = "myservice$rentokil_db_service_request_trx_get";
        var rentokil_db_service_request_trx_get_httpheaders = {};
        rentokil_db_service_request_trx_get_inputparam["httpheaders"] = rentokil_db_service_request_trx_get_httpheaders;
        var rentokil_db_service_request_trx_get_httpconfigs = {};
        rentokil_db_service_request_trx_get_inputparam["httpconfig"] = rentokil_db_service_request_trx_get_httpconfigs;
        myservice$rentokil_db_service_request_trx_get = mfintegrationsecureinvokerasync(rentokil_db_service_request_trx_get_inputparam, "myservice", "rentokil_db_service_request_trx_get", INVOKE_ASYNC_SERVICE_c93fd5a3c4234a309691bbc2d8360545_Callback);
    },
    /** init defined for SupervisorForm **/
    AS_Form_gc1a6e0432db423aa08c5bde788d3263: function AS_Form_gc1a6e0432db423aa08c5bde788d3263(eventobject) {
        var self = this;
        console.log(this, 'test');
        this.testcall(1);
        //this.invokeServiceRequest('1');
        //read previous form data
        //call api service
    }
});