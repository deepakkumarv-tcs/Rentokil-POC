define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for buttonNo **/
    AS_Button_e9e4d41721174aa482cfc482868c6979: function AS_Button_e9e4d41721174aa482cfc482868c6979(eventobject) {
        var self = this;
        self.view.isVisible = false;
        self.view.forceLayout();
    },
    /** onClick defined for buttonYes **/
    AS_Button_efb1f75e97864f6cbd7cb148142c747a: function AS_Button_efb1f75e97864f6cbd7cb148142c747a(eventobject) {
        var self = this;
        self.view.isVisible = false;
        self.view.forceLayout();
    },
    /** onTouchStart defined for imageClose **/
    AS_Image_aad23cdafe634cae8485651ccfb874c1: function AS_Image_aad23cdafe634cae8485651ccfb874c1(eventobject, x, y) {
        var self = this;
        this.view.isVisible = false;
        this.view.forceLayout();
    }
});