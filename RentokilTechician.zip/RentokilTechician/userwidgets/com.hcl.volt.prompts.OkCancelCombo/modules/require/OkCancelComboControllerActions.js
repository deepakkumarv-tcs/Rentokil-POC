define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for buttonOk **/
    AS_Button_e546259e3c1c4361bd72438fca99ae40: function AS_Button_e546259e3c1c4361bd72438fca99ae40(eventobject) {
        var self = this;
        var selectedKey = self.view.listboxSelect.selectedKey;
        self.view.isVisible = false;
        self.view.forceLayout();
    },
    /** onClick defined for buttonCancel **/
    AS_Button_g80344c640914a22afbcda820e8dc6ba: function AS_Button_g80344c640914a22afbcda820e8dc6ba(eventobject) {
        var self = this;
        self.view.isVisible = false;
        self.view.forceLayout();
    },
    /** onTouchStart defined for imageClose **/
    AS_Image_f47df156c6914636bb37c69466e88ced: function AS_Image_f47df156c6914636bb37c69466e88ced(eventobject, x, y) {
        var self = this;
        self.view.isVisible = false;
        self.view.forceLayout();
    },
    /** onSelection defined for listboxSelect **/
    AS_ListBox_b1ba33bf352c4b698c49c02dd7e1da2f: function AS_ListBox_b1ba33bf352c4b698c49c02dd7e1da2f(eventobject) {
        var self = this;
        this.view.textboxInput.text = this.view.listboxSelect.selectedKeyValue[1];
    }
});