define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0acc0925d7dab4e **/
    AS_Button_f4974b195cc34c8a96cbc1d3e3c607da: function AS_Button_f4974b195cc34c8a96cbc1d3e3c607da(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("frmHome");
        ntf.navigate({
            "ServiceID_text": self.view.ServiceID.text,
            "_meta_": {
                "eventName": "onClick",
                "widgetId": "Button0acc0925d7dab4e"
            }
        });
    }
});