define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0cdd75924512045 **/
    AS_Button_cd808a56da68441485a8a286252446d7: function AS_Button_cd808a56da68441485a8a286252446d7(eventobject) {
        var self = this;

        function SHOW_ALERT_b82b7c5c5c69488d8e4716252f80df99_True() {}

        function SHOW_ALERT_b82b7c5c5c69488d8e4716252f80df99_False() {}

        function SHOW_ALERT_b82b7c5c5c69488d8e4716252f80df99_Callback(response) {
            if (response === true) {
                SHOW_ALERT_b82b7c5c5c69488d8e4716252f80df99_True();
            } else {
                SHOW_ALERT_b82b7c5c5c69488d8e4716252f80df99_False();
            }
        }
        voltmx.ui.Alert({
            "alertType": constants.ALERT_TYPE_CONFIRMATION,
            "alertTitle": "Alert Job",
            "yesLabel": "Yes",
            "noLabel": "No",
            "alertIcon": null,
            "message": "Are you sure you want to accept this job?",
            "alertHandler": SHOW_ALERT_b82b7c5c5c69488d8e4716252f80df99_Callback
        }, {
            "iconPosition": constants.ALERT_ICON_POSITION_LEFT
        });
    },
    /** onClick defined for Button0f59a149e664e49 **/
    AS_Button_e7d5eb3ea47b4ebbaacc0ae90964a61d: function AS_Button_e7d5eb3ea47b4ebbaacc0ae90964a61d(eventobject) {
        var self = this;
    },
    /** init defined for frmHome **/
    AS_Form_ia74f70e50764e35981ea22dd4927586: function AS_Form_ia74f70e50764e35981ea22dd4927586(eventobject) {
        var self = this;
        if (this.navigationContext && this.navigationContext.ServiceID_text) {
            var service_id = this.navigationContext.ServiceID_text;
            this.fetchServiceData(service_id);
        }
    }
});