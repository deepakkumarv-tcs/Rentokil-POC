define({ 
 //Type your controller code here 
  fetchServiceData: function(id) {
	operationName =  "rentokil_db_service_request_trx_get";
   
    if (rentokil_db_service_request_trx_get_inputparam == undefined) {
        var rentokil_db_service_request_trx_get_inputparam = {
          "$filter": "SR_ID eq "+id
        };
    }
    rentokil_db_service_request_trx_get_inputparam["serviceID"] = "db_integration_service$rentokil_db_service_request_trx_get";
    var rentokil_db_service_request_trx_get_httpheaders = {};
    rentokil_db_service_request_trx_get_inputparam["httpheaders"] = rentokil_db_service_request_trx_get_httpheaders;
    var rentokil_db_service_request_trx_get_httpconfigs = {};
    rentokil_db_service_request_trx_get_inputparam["httpconfig"] = rentokil_db_service_request_trx_get_httpconfigs;
    db_integration_service$rentokil_db_service_request_trx_get = mfintegrationsecureinvokerasync(rentokil_db_service_request_trx_get_inputparam, "db_integration_service", "rentokil_db_service_request_trx_get", this.callback);
    },
  callback: function(status, response) {
     voltmx.print("API Response: " + JSON.stringify(response));
	 var self = this;
     var data = response.service_request_trx;
     if (data && data.length > 0) {
		var custName = data[0].CUSTOMER_NAME;
       var emailID = data[0].EMAIL_ID;
       var contact = data[0].PHONE;
       var address = data[0].ADDRESS;
       var area = data[0].SERVICE_AREA;
       var note = data[0].service_notes;
       self.view.custName.text = custName;
       self.view.emailContent.text = emailID;
       self.view.contactContent.text = contact;
       self.view.addressContent.text = address;
       self.view.serviceArea.text = area;
       self.view.serviceNote.text = note;
     }
   }, 
  failureCallback: function(error) {
        voltmx.print("Error: " + JSON.stringify(error));
    }

 });