//actions.js file of the project: RentokilTechician 
