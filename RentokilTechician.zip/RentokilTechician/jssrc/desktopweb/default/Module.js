//Type your code here
function getServiceRequests() {
    //Code to invoke parent integration service should be present to use below code.
    operationName = "rentokil_db_service_request_trx_get";

    function INVOKE_SERVICE_i7e0fe0b53ba494989651da3357242da_Callback(status, rentokil_db_service_request_trx_get) {
        data = rentokil_db_service_request_trx_get;
        console.log('done');
    }
    if (rentokil_db_service_request_trx_get_inputparam == undefined) {
        var rentokil_db_service_request_trx_get_inputparam = {};
    }
    rentokil_db_service_request_trx_get_inputparam["serviceID"] = "db_integration_service$rentokil_db_service_request_trx_get";
    var rentokil_db_service_request_trx_get_httpheaders = {};
    rentokil_db_service_request_trx_get_inputparam["httpheaders"] = rentokil_db_service_request_trx_get_httpheaders;
    var rentokil_db_service_request_trx_get_httpconfigs = {};
    rentokil_db_service_request_trx_get_inputparam["httpconfig"] = rentokil_db_service_request_trx_get_httpconfigs;
    db_integration_service$rentokil_db_service_request_trx_get = mfintegrationsecureinvokerasync(rentokil_db_service_request_trx_get_inputparam, "db_integration_service", "rentokil_db_service_request_trx_get", INVOKE_SERVICE_i7e0fe0b53ba494989651da3357242da_Callback);
}