voltmx.appinit.setApplicationMetaConfiguration("appid", "RentokilTechicia");
voltmx.appinit.setApplicationMetaConfiguration("build", "debug");
//startup.js
var appConfig = {
    appId: "RentokilTechicia",
    appName: "RentokilTechician",
    appVersion: "1.0.0",
    isturlbase: "http://avdgls15-4.lkil0t22tl1erkgrqhfc3qnidb.rx.internal.cloudapp.net:8080/services",
    isDebug: true,
    isMFApp: true,
    appKey: "78ba3f99372dc70701c71ef6dfe5c485",
    appSecret: "8cce16832a3079a679cb802274d0a58c",
    serviceUrl: "http://avdgls15-4.lkil0t22tl1erkgrqhfc3qnidb.rx.internal.cloudapp.net:8080/authService/100000002/appconfig",
    svcDoc: {
        "selflink": "http://avdgls15-4.lkil0t22tl1erkgrqhfc3qnidb.rx.internal.cloudapp.net:8080/authService/100000002/appconfig",
        "app_version": "1.0",
        "integsvc": {
            "_internal_logout": "http://avdgls15-4.lkil0t22tl1erkgrqhfc3qnidb.rx.internal.cloudapp.net:8080/services/IST",
            "db_integration_service": "http://avdgls15-4.lkil0t22tl1erkgrqhfc3qnidb.rx.internal.cloudapp.net:8080/services/db_integration_service"
        },
        "service_doc_etag": "0000019E342259D8",
        "appId": "ecb4ef66-4808-4bce-affa-ad2e06e42d44",
        "identity_features": {
            "reporting_params_header_allowed": true
        },
        "name": "RentokilTechician",
        "reportingsvc": {
            "session": "http://avdgls15-4.lkil0t22tl1erkgrqhfc3qnidb.rx.internal.cloudapp.net:8080/services/IST",
            "custom": "http://avdgls15-4.lkil0t22tl1erkgrqhfc3qnidb.rx.internal.cloudapp.net:8080/services/CMS"
        },
        "baseId": "4d8c1bcc-9d50-4b02-b2c9-86d2a8392b4e",
        "app_default_version": "1.0",
        "services_meta": {
            "db_integration_service": {
                "type": "integsvc",
                "version": "1.0",
                "url": "http://avdgls15-4.lkil0t22tl1erkgrqhfc3qnidb.rx.internal.cloudapp.net:8080/services/db_integration_service"
            }
        }
    },
    runtimeAppVersion: "1.0",
    eventTypes: ["FormEntry", "Error", "Crash"],
};
sessionID = "";

function setAppBehaviors() {
    voltmx.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        isMVC: true,
        responsive: true,
        APILevel: 10000,
        strictMode: false,
        isCompositeApp: false,
        packageAsPortlet: false
    })
};

function themeCallBack() {
    initializeGlobalVariables();
    voltmx.appinit.setRequireBasepath();
    require(['kvmodules'], function() {
        require(['applicationController'], function(appController) {
            applicationController = appController;
            voltmx.application.setApplicationInitializationEvents({
                init: applicationController.appInit,
                postappinit: applicationController.postAppInitCallBack,
                showstartupform: function() {
                    new voltmx.mvc.Navigation("Form1").navigate();
                }
            });
        });
    });
};

function loadResources() {
    _kony.mvc.initCompositeApp(false);
    voltmx.theme.packagedthemes(["default"]);
    globalhttpheaders = {};
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
        "appKey": appConfig.appKey,
        "appSecret": appConfig.appSecret,
        "eventTypes": appConfig.eventTypes,
        "serviceUrl": appConfig.serviceUrl,
    }
    voltmx.setupsdks(sdkInitConfig, onSuccessSDKCallBack, onSuccessSDKCallBack);
    if (voltmx.rosettajs) {
        voltmx.rosettajs.API.setDefaultFrameworkAsVoltMX();
        voltmx.rosettajs.API.converter.config.setRosettaJSname('voltmx.rosettajs');
        voltmx.rosettajs.API.setDefaultAPIAsNotes();
    }
};

function onSuccessSDKCallBack() {
    spaAPM && spaAPM.startTracking();
    voltmx.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
}

function initializeApp() {
    voltmx.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
    //This is the entry point for the application.When Locale comes,Local API call will be the entry point.
    loadResources();
};function getSPARequireModulesList(){ return ['kvmodules']; }