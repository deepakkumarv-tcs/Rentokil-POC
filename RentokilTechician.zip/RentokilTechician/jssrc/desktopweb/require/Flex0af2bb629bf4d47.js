define("Flex0af2bb629bf4d47", function() {
    return function(controller) {
        var Flex0af2bb629bf4d47 = new voltmx.ui.FlexContainer({
            "clipBounds": false,
            "height": "80dp",
            "id": "Flex0af2bb629bf4d47",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "breakpoints": [640, 1024, 1366],
            "appName": "RentokilTechician"
        }, {
            "paddingInPixel": false
        }, {});
        Flex0af2bb629bf4d47.setDefaultUnit(voltmx.flex.DP);
        Flex0af2bb629bf4d47.add();
        return Flex0af2bb629bf4d47;
    }
})