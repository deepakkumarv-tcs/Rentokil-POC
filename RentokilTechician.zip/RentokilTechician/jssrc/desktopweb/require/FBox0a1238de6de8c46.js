define("FBox0a1238de6de8c46", function() {
    return function(controller) {
        FBox0a1238de6de8c46 = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
            "clipBounds": false,
            "id": "FBox0a1238de6de8c46",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "100%",
            "appName": "RentokilTechician"
        }, {
            "paddingInPixel": false
        }, {});
        FBox0a1238de6de8c46.setDefaultUnit(voltmx.flex.DP);
        var lblSRID = new voltmx.ui.Label({
            "height": "60px",
            "id": "lblSRID",
            "isVisible": true,
            "left": "0dp",
            "maxNumberOfLines": 2,
            "text": "SR ID",
            "textTruncatePosition": constants.TEXT_TRUNCATE_END,
            "top": "0dp",
            "width": "100%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [20, 0, 0, 0],
            "paddingInPixel": true
        }, {});
        var lblCUSTOMERNAME = new voltmx.ui.Label({
            "height": "60px",
            "id": "lblCUSTOMERNAME",
            "isVisible": true,
            "left": "0dp",
            "maxNumberOfLines": 2,
            "text": "CUSTOMER NAME",
            "textTruncatePosition": constants.TEXT_TRUNCATE_END,
            "top": "0dp",
            "width": "100%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [25, 0, 0, 0],
            "paddingInPixel": true
        }, {});
        var lblEMAILID = new voltmx.ui.Label({
            "height": "60px",
            "id": "lblEMAILID",
            "isVisible": true,
            "left": "0dp",
            "maxNumberOfLines": 2,
            "text": "EMAIL ID",
            "textTruncatePosition": constants.TEXT_TRUNCATE_END,
            "top": "0dp",
            "width": "100%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [25, 0, 0, 0],
            "paddingInPixel": true
        }, {});
        var lblPHONE = new voltmx.ui.Label({
            "height": "60px",
            "id": "lblPHONE",
            "isVisible": true,
            "left": "0dp",
            "maxNumberOfLines": 2,
            "text": "PHONE",
            "textTruncatePosition": constants.TEXT_TRUNCATE_END,
            "top": "0dp",
            "width": "100%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [25, 0, 0, 0],
            "paddingInPixel": true
        }, {});
        var lblSERVICEAREA = new voltmx.ui.Label({
            "height": "60px",
            "id": "lblSERVICEAREA",
            "isVisible": true,
            "left": "0dp",
            "maxNumberOfLines": 2,
            "text": "SERVICE AREA",
            "textTruncatePosition": constants.TEXT_TRUNCATE_END,
            "top": "0dp",
            "width": "100%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [25, 0, 0, 0],
            "paddingInPixel": true
        }, {});
        var lblPESTCONTROLTYPEID = new voltmx.ui.Label({
            "height": "60px",
            "id": "lblPESTCONTROLTYPEID",
            "isVisible": true,
            "left": "0dp",
            "maxNumberOfLines": 2,
            "text": "PEST CONTROL TYPE ID",
            "textTruncatePosition": constants.TEXT_TRUNCATE_END,
            "top": "0dp",
            "width": "100%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [25, 0, 0, 0],
            "paddingInPixel": true
        }, {});
        var lblTECHNICIANID = new voltmx.ui.Label({
            "height": "60px",
            "id": "lblTECHNICIANID",
            "isVisible": true,
            "left": "0dp",
            "maxNumberOfLines": 2,
            "text": "TECHNICIAN ID",
            "textTruncatePosition": constants.TEXT_TRUNCATE_END,
            "top": "0dp",
            "width": "100%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [25, 0, 0, 0],
            "paddingInPixel": true
        }, {});
        var lblADDRESS = new voltmx.ui.Label({
            "height": "60px",
            "id": "lblADDRESS",
            "isVisible": true,
            "left": "0dp",
            "maxNumberOfLines": 2,
            "text": "ADDRESS",
            "textTruncatePosition": constants.TEXT_TRUNCATE_END,
            "top": "0dp",
            "width": "100%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [25, 0, 0, 0],
            "paddingInPixel": true
        }, {});
        var lblLOCATIONID = new voltmx.ui.Label({
            "height": "60px",
            "id": "lblLOCATIONID",
            "isVisible": true,
            "left": "0dp",
            "maxNumberOfLines": 2,
            "text": "LOCATION ID",
            "textTruncatePosition": constants.TEXT_TRUNCATE_END,
            "top": "0dp",
            "width": "100%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [25, 0, 0, 0],
            "paddingInPixel": true
        }, {});
        var lblCITY = new voltmx.ui.Label({
            "height": "60px",
            "id": "lblCITY",
            "isVisible": true,
            "left": "0dp",
            "maxNumberOfLines": 2,
            "text": "CITY",
            "textTruncatePosition": constants.TEXT_TRUNCATE_END,
            "top": "0dp",
            "width": "100%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [25, 0, 0, 0],
            "paddingInPixel": true
        }, {});
        var lblSERVICEDESCRIPTION = new voltmx.ui.Label({
            "height": "60px",
            "id": "lblSERVICEDESCRIPTION",
            "isVisible": true,
            "left": "0dp",
            "maxNumberOfLines": 2,
            "text": "SERVICE DESCRIPTION",
            "textTruncatePosition": constants.TEXT_TRUNCATE_END,
            "top": "0dp",
            "width": "100%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [25, 0, 0, 0],
            "paddingInPixel": true
        }, {});
        var lblSERVICESTATUS = new voltmx.ui.Label({
            "height": "60px",
            "id": "lblSERVICESTATUS",
            "isVisible": true,
            "left": "0dp",
            "maxNumberOfLines": 2,
            "text": "SERVICE STATUS",
            "textTruncatePosition": constants.TEXT_TRUNCATE_END,
            "top": "0dp",
            "width": "100%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [25, 0, 0, 0],
            "paddingInPixel": true
        }, {});
        var lbltasksperformed = new voltmx.ui.Label({
            "height": "60px",
            "id": "lbltasksperformed",
            "isVisible": true,
            "left": "0dp",
            "maxNumberOfLines": 2,
            "text": "Tasks Performed",
            "textTruncatePosition": constants.TEXT_TRUNCATE_END,
            "top": "0dp",
            "width": "100%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [25, 0, 0, 0],
            "paddingInPixel": true
        }, {});
        var lblservicenotes = new voltmx.ui.Label({
            "height": "60px",
            "id": "lblservicenotes",
            "isVisible": true,
            "left": "0dp",
            "maxNumberOfLines": 2,
            "text": "Service Notes",
            "textTruncatePosition": constants.TEXT_TRUNCATE_END,
            "top": "0dp",
            "width": "100%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [25, 0, 0, 0],
            "paddingInPixel": true
        }, {});
        var lblmaterialsused = new voltmx.ui.Label({
            "height": "60px",
            "id": "lblmaterialsused",
            "isVisible": true,
            "left": "0dp",
            "maxNumberOfLines": 2,
            "text": "Materials Used",
            "textTruncatePosition": constants.TEXT_TRUNCATE_END,
            "top": "0dp",
            "width": "100%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [25, 0, 0, 0],
            "paddingInPixel": true
        }, {});
        FBox0a1238de6de8c46.add(lblSRID, lblCUSTOMERNAME, lblEMAILID, lblPHONE, lblSERVICEAREA, lblPESTCONTROLTYPEID, lblTECHNICIANID, lblADDRESS, lblLOCATIONID, lblCITY, lblSERVICEDESCRIPTION, lblSERVICESTATUS, lbltasksperformed, lblservicenotes, lblmaterialsused);
        return FBox0a1238de6de8c46;
    }
})