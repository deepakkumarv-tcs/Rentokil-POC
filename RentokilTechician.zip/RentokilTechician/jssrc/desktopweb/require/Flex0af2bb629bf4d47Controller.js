define("userFlex0af2bb629bf4d47Controller", {
    //Type your controller code here 
});
define("Flex0af2bb629bf4d47ControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("Flex0af2bb629bf4d47Controller", ["userFlex0af2bb629bf4d47Controller", "Flex0af2bb629bf4d47ControllerActions"], function() {
    var controller = require("userFlex0af2bb629bf4d47Controller");
    var controllerActions = ["Flex0af2bb629bf4d47ControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
