define("userFBox0a1238de6de8c46Controller", {
    //Type your controller code here 
});
define("FBox0a1238de6de8c46ControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("FBox0a1238de6de8c46Controller", ["userFBox0a1238de6de8c46Controller", "FBox0a1238de6de8c46ControllerActions"], function() {
    var controller = require("userFBox0a1238de6de8c46Controller");
    var controllerActions = ["FBox0a1238de6de8c46ControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
