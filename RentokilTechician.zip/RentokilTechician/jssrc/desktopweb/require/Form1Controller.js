define("userForm1Controller", {
    //Type your controller code here 
});
define("Form1ControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_jd16858436184827af9c1223bd79967f: function AS_Button_jd16858436184827af9c1223bd79967f(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "RentokilTechician",
            "friendlyName": "Form2"
        });
        ntf.navigate();
    },
    AS_Button_e7d5eb3ea47b4ebbaacc0ae90964a61d: function AS_Button_e7d5eb3ea47b4ebbaacc0ae90964a61d(eventobject) {
        var self = this;
        return getServiceRequests.call(this);
    },
    AS_Form_c01249719e8946f89e62a94ddff1abd1: function AS_Form_c01249719e8946f89e62a94ddff1abd1(eventobject) {
        var self = this;
        return getServiceRequests.call(this);
    }
});
define("Form1Controller", ["userForm1Controller", "Form1ControllerActions"], function() {
    var controller = require("userForm1Controller");
    var controllerActions = ["Form1ControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
