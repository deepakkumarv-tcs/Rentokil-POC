define("Form1", function() {
    return function(controller) {
        function addWidgetsForm1() {
            this.setDefaultUnit(voltmx.flex.DP);
            var flxScrollContainer = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxScrollContainer",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "CopyslFSbox0a314b286f42e45",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxScrollContainer.setDefaultUnit(voltmx.flex.DP);
            var flxHeader = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "52px",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "CopyslFbox0g9c2fc82008a48",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(voltmx.flex.DP);
            flxHeader.add();
            var flxSidebar = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxSidebar",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "CopyslFbox0b30a680716a342",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxSidebar.setDefaultUnit(voltmx.flex.DP);
            flxSidebar.add();
            var flxMainContainer = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "CopyslFbox0d168020e900d40",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 9
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(voltmx.flex.DP);
            var breadcrumbContainer = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "45px",
                "id": "breadcrumbContainer",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0h670dfe450ba48",
                "top": "0dp",
                "width": "100%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            breadcrumbContainer.setDefaultUnit(voltmx.flex.DP);
            var breadcrumbOne = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "breadcrumbOne",
                "isVisible": true,
                "left": "0%",
                "skin": "CopydefLabel0c5ca1d3c1cb848",
                "text": "Orders",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [24, 0, 0, 0],
                "paddingInPixel": true
            }, {});
            var AngleRight = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "AngleRight",
                "isVisible": true,
                "skin": "CopyslFontAwesomeIcon0g813e6b8396c4d",
                "text": "",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [8, 0, 8, 0],
                "paddingInPixel": true
            }, {});
            var breadCrumbTwo = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "breadCrumbTwo",
                "isVisible": true,
                "left": "0%",
                "skin": "CopydefLabel0ec9012bba3a44c",
                "text": "Label",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": true
            }, {});
            breadcrumbContainer.add(breadcrumbOne, AngleRight, breadCrumbTwo);
            var flxJobDetails = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "gutterX": "16dp",
                "gutterY": "16px",
                "clipBounds": false,
                "height": "100%",
                "id": "flxJobDetails",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "isModalContainer": false,
                "skin": "CopyslFbox0b1d08198ac854d",
                "top": "0dp",
                "width": "100%",
                "appName": "RentokilTechician"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxJobDetails.setDefaultUnit(voltmx.flex.DP);
            var flxOne = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "56px",
                "id": "flxOne",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "CopyslFbox0fa055b9e4aee41",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 12
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxOne.setDefaultUnit(voltmx.flex.DP);
            var Label0af7e4d5b965a45 = new voltmx.ui.Label({
                "id": "Label0af7e4d5b965a45",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0i2c53b0889434a",
                "text": "Job Details",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOne.add(Label0af7e4d5b965a45);
            var flxTwo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTwo",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "CopyslFbox0i647d3d608a245",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 12
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxTwo.setDefaultUnit(voltmx.flex.DP);
            var custInfoLabel = new voltmx.ui.Label({
                "id": "custInfoLabel",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0e3f8d31ac14d4b",
                "text": "Customer Information",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [16, 16, 0, 8],
                "paddingInPixel": true
            }, {});
            var custDetails = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "16px",
                "gutterY": "24px",
                "clipBounds": false,
                "id": "custDetails",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "0",
                "isModalContainer": false,
                "skin": "CopyslFbox0ge8051f777324b",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "appName": "RentokilTechician"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            custDetails.setDefaultUnit(voltmx.flex.DP);
            var flxName = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxName",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "CopyslFbox0hd360c6db69448",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxName.setDefaultUnit(voltmx.flex.DP);
            var flxNameIcon = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNameIcon",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "CopyslFbox0dd9e79a2876a45",
                "top": "0dp",
                "width": "15%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameIcon.setDefaultUnit(voltmx.flex.DP);
            var User = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "User",
                "isVisible": true,
                "skin": "CopyslFontAwesomeIcon0d160d91e7dff46",
                "text": "",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNameIcon.add(User);
            var flxNameInfo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNameInfo",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "itemInfo",
                "top": "0",
                "width": "85%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameInfo.setDefaultUnit(voltmx.flex.DP);
            var itemLabel = new voltmx.ui.Label({
                "id": "itemLabel",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0j671ee4f661340",
                "text": "Name",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var itemContent = new voltmx.ui.Label({
                "id": "itemContent",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0ibf72de05d124a",
                "text": "Priya Mehta",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNameInfo.add(itemLabel, itemContent);
            flxName.add(flxNameIcon, flxNameInfo);
            var flxName0g0c4ed14ac554b = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxName0g0c4ed14ac554b",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0hdfd110015ca41",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxName0g0c4ed14ac554b.setDefaultUnit(voltmx.flex.DP);
            var flxNameIcon0c131027f1b4a49 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNameIcon0c131027f1b4a49",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0b606aa7a431f48",
                "top": "0dp",
                "width": "15%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameIcon0c131027f1b4a49.setDefaultUnit(voltmx.flex.DP);
            var User0a57c6a2ab7fc47 = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "User0a57c6a2ab7fc47",
                "isVisible": true,
                "skin": "CopyslFontAwesomeIcon0gec93abb002d47",
                "text": "",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNameIcon0c131027f1b4a49.add(User0a57c6a2ab7fc47);
            var flxNameInfo0c31b2e2a1fe148 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNameInfo0c31b2e2a1fe148",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "itemInfo0f24554ee72054e",
                "top": "0",
                "width": "85%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameInfo0c31b2e2a1fe148.setDefaultUnit(voltmx.flex.DP);
            var itemLabel0c122ee6583b94f = new voltmx.ui.Label({
                "id": "itemLabel0c122ee6583b94f",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0cc5d36a3c6eb49",
                "text": "Time",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var itemContent0be69ed1d85eb47 = new voltmx.ui.Label({
                "id": "itemContent0be69ed1d85eb47",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0c6512e3926c647",
                "text": "4:00 PM - 6:00 PM",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNameInfo0c31b2e2a1fe148.add(itemLabel0c122ee6583b94f, itemContent0be69ed1d85eb47);
            flxName0g0c4ed14ac554b.add(flxNameIcon0c131027f1b4a49, flxNameInfo0c31b2e2a1fe148);
            var flxName0ab982f3ea81d48 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxName0ab982f3ea81d48",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0f39609c71ab24e",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxName0ab982f3ea81d48.setDefaultUnit(voltmx.flex.DP);
            var flxNameIcon0a7b48f016a9040 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNameIcon0a7b48f016a9040",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0da4c38e45d6f4e",
                "top": "0dp",
                "width": "15%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameIcon0a7b48f016a9040.setDefaultUnit(voltmx.flex.DP);
            var User0ic50d3e7d03241 = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "User0ic50d3e7d03241",
                "isVisible": true,
                "skin": "CopyslFontAwesomeIcon0g931522ac5be45",
                "text": "",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNameIcon0a7b48f016a9040.add(User0ic50d3e7d03241);
            var flxNameInfo0e0f045d733e744 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNameInfo0e0f045d733e744",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "itemInfo0ifb7799675e54d",
                "top": "0",
                "width": "85%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameInfo0e0f045d733e744.setDefaultUnit(voltmx.flex.DP);
            var itemLabel0adc96106fecb4b = new voltmx.ui.Label({
                "id": "itemLabel0adc96106fecb4b",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0c9ab40b7443b48",
                "text": "Email id",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var itemContent0faeeccb098ae45 = new voltmx.ui.Label({
                "id": "itemContent0faeeccb098ae45",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0f59b2391dfc543",
                "text": "priya.mehta@gmail.com",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNameInfo0e0f045d733e744.add(itemLabel0adc96106fecb4b, itemContent0faeeccb098ae45);
            flxName0ab982f3ea81d48.add(flxNameIcon0a7b48f016a9040, flxNameInfo0e0f045d733e744);
            var flxName0cafb66fb5aa940 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxName0cafb66fb5aa940",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0d00e415d892042",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxName0cafb66fb5aa940.setDefaultUnit(voltmx.flex.DP);
            var flxNameIcon0f14c585134e245 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNameIcon0f14c585134e245",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0a404984096204d",
                "top": "0dp",
                "width": "15%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameIcon0f14c585134e245.setDefaultUnit(voltmx.flex.DP);
            var User0f03ffca3669a44 = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "User0f03ffca3669a44",
                "isVisible": true,
                "skin": "CopyslFontAwesomeIcon0ee8dc005b8b945",
                "text": "",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNameIcon0f14c585134e245.add(User0f03ffca3669a44);
            var flxNameInfo0baa2290992654d = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNameInfo0baa2290992654d",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "itemInfo0h825105dcd704f",
                "top": "0",
                "width": "85%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameInfo0baa2290992654d.setDefaultUnit(voltmx.flex.DP);
            var itemLabel0b236bcff9c174d = new voltmx.ui.Label({
                "id": "itemLabel0b236bcff9c174d",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0jffea80dc3e04e",
                "text": "Contact",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var itemContent0j83655fbea8446 = new voltmx.ui.Label({
                "id": "itemContent0j83655fbea8446",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0ae3b04634a784a",
                "text": "+91 9982631270",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNameInfo0baa2290992654d.add(itemLabel0b236bcff9c174d, itemContent0j83655fbea8446);
            flxName0cafb66fb5aa940.add(flxNameIcon0f14c585134e245, flxNameInfo0baa2290992654d);
            var flxName0h4075780bfb04c = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxName0h4075780bfb04c",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0bb01ee6239314a",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxName0h4075780bfb04c.setDefaultUnit(voltmx.flex.DP);
            var flxNameIcon0bd514be5191345 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNameIcon0bd514be5191345",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0ac0daadc8e204b",
                "top": "0dp",
                "width": "15%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameIcon0bd514be5191345.setDefaultUnit(voltmx.flex.DP);
            var User0fb4994a28f4b4a = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "User0fb4994a28f4b4a",
                "isVisible": true,
                "skin": "CopyslFontAwesomeIcon0ddcbf8de7c9d45",
                "text": "",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNameIcon0bd514be5191345.add(User0fb4994a28f4b4a);
            var flxNameInfo0i3540a1c329840 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNameInfo0i3540a1c329840",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "itemInfo0jba5077a2a614c",
                "top": "0",
                "width": "85%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameInfo0i3540a1c329840.setDefaultUnit(voltmx.flex.DP);
            var itemLabel0f0df140d6a8c4d = new voltmx.ui.Label({
                "id": "itemLabel0f0df140d6a8c4d",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0ed76de03b56047",
                "text": "Date",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var itemContent0g7e9822a07fb46 = new voltmx.ui.Label({
                "id": "itemContent0g7e9822a07fb46",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0ac486df112f94a",
                "text": "8 May 2026",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNameInfo0i3540a1c329840.add(itemLabel0f0df140d6a8c4d, itemContent0g7e9822a07fb46);
            flxName0h4075780bfb04c.add(flxNameIcon0bd514be5191345, flxNameInfo0i3540a1c329840);
            var flxName0iea2408e401342 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxName0iea2408e401342",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0e539e98916c14e",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxName0iea2408e401342.setDefaultUnit(voltmx.flex.DP);
            var flxNameIcon0ac60292e157242 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNameIcon0ac60292e157242",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0ebe4b467423741",
                "top": "0dp",
                "width": "15%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameIcon0ac60292e157242.setDefaultUnit(voltmx.flex.DP);
            var User0b3d8757d461e45 = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "User0b3d8757d461e45",
                "isVisible": true,
                "skin": "CopyslFontAwesomeIcon0a11531cd85a942",
                "text": "",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNameIcon0ac60292e157242.add(User0b3d8757d461e45);
            var flxNameInfo0j870c442d5d742 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNameInfo0j870c442d5d742",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "itemInfo0id47baaeecb34d",
                "top": "0",
                "width": "85%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameInfo0j870c442d5d742.setDefaultUnit(voltmx.flex.DP);
            var itemLabel0da6a3937da7548 = new voltmx.ui.Label({
                "id": "itemLabel0da6a3937da7548",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0i5ac91bde6e54a",
                "text": "Address",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var itemContent0he1301f6ef6c40 = new voltmx.ui.Label({
                "id": "itemContent0he1301f6ef6c40",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0id8fbc21c1c540",
                "text": "198, Walker street, near mandir Madhapur, Hyderabad",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNameInfo0j870c442d5d742.add(itemLabel0da6a3937da7548, itemContent0he1301f6ef6c40);
            flxName0iea2408e401342.add(flxNameIcon0ac60292e157242, flxNameInfo0j870c442d5d742);
            custDetails.add(flxName, flxName0g0c4ed14ac554b, flxName0ab982f3ea81d48, flxName0cafb66fb5aa940, flxName0h4075780bfb04c, flxName0iea2408e401342);
            flxTwo.add(custInfoLabel, custDetails);
            var CopyflxTwo0e0659227c9d242 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxTwo0e0659227c9d242",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "CopyslFbox0i647d3d608a245",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 12
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxTwo0e0659227c9d242.setDefaultUnit(voltmx.flex.DP);
            var CopycustInfoLabel0e7e3dc738b3544 = new voltmx.ui.Label({
                "id": "CopycustInfoLabel0e7e3dc738b3544",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0e3f8d31ac14d4b",
                "text": "Booking Details",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [16, 16, 0, 8],
                "paddingInPixel": true
            }, {});
            var CopycustDetails0ccb1334f389442 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "16px",
                "gutterY": "24px",
                "clipBounds": false,
                "id": "CopycustDetails0ccb1334f389442",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "0",
                "isModalContainer": false,
                "skin": "CopyslFbox0ge8051f777324b",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "appName": "RentokilTechician"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopycustDetails0ccb1334f389442.setDefaultUnit(voltmx.flex.DP);
            var CopyflxName0d24b9d2a344f47 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxName0d24b9d2a344f47",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0f39609c71ab24e",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxName0d24b9d2a344f47.setDefaultUnit(voltmx.flex.DP);
            var CopyflxNameIcon0db3f635194b040 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxNameIcon0db3f635194b040",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0da4c38e45d6f4e",
                "top": "0dp",
                "width": "15%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxNameIcon0db3f635194b040.setDefaultUnit(voltmx.flex.DP);
            var CopyUser0cbfb9f86180b48 = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "CopyUser0cbfb9f86180b48",
                "isVisible": true,
                "skin": "CopyslFontAwesomeIcon0g931522ac5be45",
                "text": "",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxNameIcon0db3f635194b040.add(CopyUser0cbfb9f86180b48);
            var CopyflxNameInfo0c8e962b863d747 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxNameInfo0c8e962b863d747",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "itemInfo0ifb7799675e54d",
                "top": "0",
                "width": "85%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxNameInfo0c8e962b863d747.setDefaultUnit(voltmx.flex.DP);
            var CopyitemLabel0gd6bdb773a5949 = new voltmx.ui.Label({
                "id": "CopyitemLabel0gd6bdb773a5949",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0c9ab40b7443b48",
                "text": "Service",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyitemContent0a88b28048e5547 = new voltmx.ui.Label({
                "id": "CopyitemContent0a88b28048e5547",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0f59b2391dfc543",
                "text": "General pest control",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxNameInfo0c8e962b863d747.add(CopyitemLabel0gd6bdb773a5949, CopyitemContent0a88b28048e5547);
            CopyflxName0d24b9d2a344f47.add(CopyflxNameIcon0db3f635194b040, CopyflxNameInfo0c8e962b863d747);
            var CopyflxName0ac073512870a4a = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxName0ac073512870a4a",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0d00e415d892042",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxName0ac073512870a4a.setDefaultUnit(voltmx.flex.DP);
            var CopyflxNameIcon0f3b214ecc5894c = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxNameIcon0f3b214ecc5894c",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0a404984096204d",
                "top": "0dp",
                "width": "15%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxNameIcon0f3b214ecc5894c.setDefaultUnit(voltmx.flex.DP);
            var CopyUser0ie9dde6992db42 = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "CopyUser0ie9dde6992db42",
                "isVisible": true,
                "skin": "CopyslFontAwesomeIcon0ee8dc005b8b945",
                "text": "",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxNameIcon0f3b214ecc5894c.add(CopyUser0ie9dde6992db42);
            var CopyflxNameInfo0if52302dab5240 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxNameInfo0if52302dab5240",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "itemInfo0h825105dcd704f",
                "top": "0",
                "width": "85%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxNameInfo0if52302dab5240.setDefaultUnit(voltmx.flex.DP);
            var CopyitemLabel0gad1f7b2ce7c4c = new voltmx.ui.Label({
                "id": "CopyitemLabel0gad1f7b2ce7c4c",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0jffea80dc3e04e",
                "text": "Area",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyitemContent0i7829b282cdd44 = new voltmx.ui.Label({
                "id": "CopyitemContent0i7829b282cdd44",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0ae3b04634a784a",
                "text": "Medium <500 sq. ft.",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxNameInfo0if52302dab5240.add(CopyitemLabel0gad1f7b2ce7c4c, CopyitemContent0i7829b282cdd44);
            CopyflxName0ac073512870a4a.add(CopyflxNameIcon0f3b214ecc5894c, CopyflxNameInfo0if52302dab5240);
            var CopyflxName0ccfdbc73a64041 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxName0ccfdbc73a64041",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0bb01ee6239314a",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxName0ccfdbc73a64041.setDefaultUnit(voltmx.flex.DP);
            var CopyflxNameIcon0fab024d126ad4e = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxNameIcon0fab024d126ad4e",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0ac0daadc8e204b",
                "top": "0dp",
                "width": "15%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxNameIcon0fab024d126ad4e.setDefaultUnit(voltmx.flex.DP);
            var CopyUser0bcd48b34c8664f = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "CopyUser0bcd48b34c8664f",
                "isVisible": true,
                "skin": "CopyslFontAwesomeIcon0ddcbf8de7c9d45",
                "text": "",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxNameIcon0fab024d126ad4e.add(CopyUser0bcd48b34c8664f);
            var CopyflxNameInfo0e8e6d71e90e74b = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxNameInfo0e8e6d71e90e74b",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "itemInfo0jba5077a2a614c",
                "top": "0",
                "width": "85%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxNameInfo0e8e6d71e90e74b.setDefaultUnit(voltmx.flex.DP);
            var CopyitemLabel0f70ca5b20f2349 = new voltmx.ui.Label({
                "id": "CopyitemLabel0f70ca5b20f2349",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0ed76de03b56047",
                "text": "Booking ID",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyitemContent0f1a3bd3f29d249 = new voltmx.ui.Label({
                "id": "CopyitemContent0f1a3bd3f29d249",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0ac486df112f94a",
                "text": "B123456",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxNameInfo0e8e6d71e90e74b.add(CopyitemLabel0f70ca5b20f2349, CopyitemContent0f1a3bd3f29d249);
            CopyflxName0ccfdbc73a64041.add(CopyflxNameIcon0fab024d126ad4e, CopyflxNameInfo0e8e6d71e90e74b);
            var CopyflxName0b01b1b99822241 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxName0b01b1b99822241",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0e539e98916c14e",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxName0b01b1b99822241.setDefaultUnit(voltmx.flex.DP);
            var CopyflxNameIcon0j1aced45e8424e = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxNameIcon0j1aced45e8424e",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0ebe4b467423741",
                "top": "0dp",
                "width": "15%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxNameIcon0j1aced45e8424e.setDefaultUnit(voltmx.flex.DP);
            var CopyUser0a1a95f5ab92d48 = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "CopyUser0a1a95f5ab92d48",
                "isVisible": true,
                "skin": "CopyslFontAwesomeIcon0a11531cd85a942",
                "text": "",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxNameIcon0j1aced45e8424e.add(CopyUser0a1a95f5ab92d48);
            var CopyflxNameInfo0j783313923c743 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxNameInfo0j783313923c743",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "itemInfo0id47baaeecb34d",
                "top": "0",
                "width": "85%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxNameInfo0j783313923c743.setDefaultUnit(voltmx.flex.DP);
            var CopyitemLabel0f49755990e2f4a = new voltmx.ui.Label({
                "id": "CopyitemLabel0f49755990e2f4a",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0i5ac91bde6e54a",
                "text": "Note",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyitemContent0fa264fddf57c44 = new voltmx.ui.Label({
                "id": "CopyitemContent0fa264fddf57c44",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0id8fbc21c1c540",
                "text": "Requested an eco-friendly treatment and pet friendly products.",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxNameInfo0j783313923c743.add(CopyitemLabel0f49755990e2f4a, CopyitemContent0fa264fddf57c44);
            CopyflxName0b01b1b99822241.add(CopyflxNameIcon0j1aced45e8424e, CopyflxNameInfo0j783313923c743);
            CopycustDetails0ccb1334f389442.add(CopyflxName0d24b9d2a344f47, CopyflxName0ac073512870a4a, CopyflxName0ccfdbc73a64041, CopyflxName0b01b1b99822241);
            CopyflxTwo0e0659227c9d242.add(CopycustInfoLabel0e7e3dc738b3544, CopycustDetails0ccb1334f389442);
            var CopyflxTwo0c45bae026a8f4b = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxTwo0c45bae026a8f4b",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "CopyslFbox0i647d3d608a245",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 12
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxTwo0c45bae026a8f4b.setDefaultUnit(voltmx.flex.DP);
            var CopycustInfoLabel0b26e96a6de364b = new voltmx.ui.Label({
                "id": "CopycustInfoLabel0b26e96a6de364b",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0e3f8d31ac14d4b",
                "text": "Instructions",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [16, 16, 8, 8],
                "paddingInPixel": true
            }, {});
            var CopycustDetails0i837c03cfa3a4e = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "16px",
                "gutterY": "24px",
                "clipBounds": false,
                "id": "CopycustDetails0i837c03cfa3a4e",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "0",
                "isModalContainer": false,
                "skin": "CopyslFbox0ge8051f777324b",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "appName": "RentokilTechician"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopycustDetails0i837c03cfa3a4e.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0iff6aaa5fa624d = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "FlexContainer0iff6aaa5fa624d",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "CopyslFbox0c27d5fbe8ad648",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0iff6aaa5fa624d.setDefaultUnit(voltmx.flex.DP);
            var FileTextLight = new voltmx.ui.Label({
                "bottom": "0",
                "id": "FileTextLight",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopyslFontAwesomeIcon0d4ef4ef02e2040",
                "text": "",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 8, 0],
                "paddingInPixel": true
            }, {});
            var Label0gad38efc700240 = new voltmx.ui.Label({
                "id": "Label0gad38efc700240",
                "isVisible": true,
                "left": "0",
                "skin": "CopydefLabel0a4d440b2fc5549",
                "text": "Pest Control Procedure.pdf",
                "top": "0",
                "width": voltmx.flex.USE_PREFERRED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0iff6aaa5fa624d.add(FileTextLight, Label0gad38efc700240);
            CopycustDetails0i837c03cfa3a4e.add(FlexContainer0iff6aaa5fa624d);
            CopyflxTwo0c45bae026a8f4b.add(CopycustInfoLabel0b26e96a6de364b, CopycustDetails0i837c03cfa3a4e);
            var FlexContainer0i99db818f60e4e = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "FlexContainer0i99db818f60e4e",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "skin": "CopyslFbox0d71958c7624c44",
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 7
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 5
                    }
                },
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0i99db818f60e4e.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0a207c7512dd447 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "FlexContainer0a207c7512dd447",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "CopyslFbox0d989aa7a2c8640",
                "top": "0",
                "width": "100%",
                "appName": "RentokilTechician"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0a207c7512dd447.setDefaultUnit(voltmx.flex.DP);
            var Button0f59a149e664e49 = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "40px",
                "id": "Button0f59a149e664e49",
                "isVisible": true,
                "left": "24px",
                "onClick": controller.AS_Button_e7d5eb3ea47b4ebbaacc0ae90964a61d,
                "skin": "CopydefBtnNormal0fbd9a39dde6946",
                "text": "Maps",
                "top": "0",
                "width": "150px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0cdd75924512045 = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "40px",
                "id": "Button0cdd75924512045",
                "isVisible": true,
                "left": "16px",
                "onClick": controller.AS_Button_jd16858436184827af9c1223bd79967f,
                "right": "16px",
                "skin": "CopydefBtnNormal0df65931d84af46",
                "text": "Accept Job",
                "top": "0",
                "width": "150px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [4, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0a207c7512dd447.add(Button0f59a149e664e49, Button0cdd75924512045);
            FlexContainer0i99db818f60e4e.add(FlexContainer0a207c7512dd447);
            flxJobDetails.add(flxOne, flxTwo, CopyflxTwo0e0659227c9d242, CopyflxTwo0c45bae026a8f4b, FlexContainer0i99db818f60e4e);
            flxMainContainer.add(breadcrumbContainer, flxJobDetails);
            flxScrollContainer.add(flxHeader, flxSidebar, flxMainContainer);
            this.compInstData = {}
            this.add(flxScrollContainer);
        };
        return [{
            "addWidgets": addWidgetsForm1,
            "enabledForIdleTimeout": false,
            "id": "Form1",
            "init": controller.AS_Form_c01249719e8946f89e62a94ddff1abd1,
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "CopyslForm0ae2fd6266d9548",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "RentokilTechician"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});