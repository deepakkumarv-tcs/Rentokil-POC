define("Form2", function() {
    return function(controller) {
        function addWidgetsForm2() {
            this.setDefaultUnit(voltmx.flex.DP);
            voltmx.mvc.registry.add('FBox0a1238de6de8c46', 'FBox0a1238de6de8c46', 'FBox0a1238de6de8c46Controller');
            var Segment0cf06365cb65444 = new voltmx.ui.SegmentedUI2({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "data": [{
                    "lblADDRESS": "ADDRESS",
                    "lblCITY": "CITY",
                    "lblCUSTOMERNAME": "CUSTOMER NAME",
                    "lblEMAILID": "EMAIL ID",
                    "lblLOCATIONID": "LOCATION ID",
                    "lblPESTCONTROLTYPEID": "PEST CONTROL TYPE ID",
                    "lblPHONE": "PHONE",
                    "lblSERVICEAREA": "SERVICE AREA",
                    "lblSERVICEDESCRIPTION": "SERVICE DESCRIPTION",
                    "lblSERVICESTATUS": "SERVICE STATUS",
                    "lblSRID": "SR ID",
                    "lblTECHNICIANID": "TECHNICIAN ID",
                    "lblmaterialsused": "Materials Used",
                    "lblservicenotes": "Service Notes",
                    "lbltasksperformed": "Tasks Performed"
                }, {
                    "lblADDRESS": "ADDRESS",
                    "lblCITY": "CITY",
                    "lblCUSTOMERNAME": "CUSTOMER NAME",
                    "lblEMAILID": "EMAIL ID",
                    "lblLOCATIONID": "LOCATION ID",
                    "lblPESTCONTROLTYPEID": "PEST CONTROL TYPE ID",
                    "lblPHONE": "PHONE",
                    "lblSERVICEAREA": "SERVICE AREA",
                    "lblSERVICEDESCRIPTION": "SERVICE DESCRIPTION",
                    "lblSERVICESTATUS": "SERVICE STATUS",
                    "lblSRID": "SR ID",
                    "lblTECHNICIANID": "TECHNICIAN ID",
                    "lblmaterialsused": "Materials Used",
                    "lblservicenotes": "Service Notes",
                    "lbltasksperformed": "Tasks Performed"
                }, {
                    "lblADDRESS": "ADDRESS",
                    "lblCITY": "CITY",
                    "lblCUSTOMERNAME": "CUSTOMER NAME",
                    "lblEMAILID": "EMAIL ID",
                    "lblLOCATIONID": "LOCATION ID",
                    "lblPESTCONTROLTYPEID": "PEST CONTROL TYPE ID",
                    "lblPHONE": "PHONE",
                    "lblSERVICEAREA": "SERVICE AREA",
                    "lblSERVICEDESCRIPTION": "SERVICE DESCRIPTION",
                    "lblSERVICESTATUS": "SERVICE STATUS",
                    "lblSRID": "SR ID",
                    "lblTECHNICIANID": "TECHNICIAN ID",
                    "lblmaterialsused": "Materials Used",
                    "lblservicenotes": "Service Notes",
                    "lbltasksperformed": "Tasks Performed"
                }, {
                    "lblADDRESS": "ADDRESS",
                    "lblCITY": "CITY",
                    "lblCUSTOMERNAME": "CUSTOMER NAME",
                    "lblEMAILID": "EMAIL ID",
                    "lblLOCATIONID": "LOCATION ID",
                    "lblPESTCONTROLTYPEID": "PEST CONTROL TYPE ID",
                    "lblPHONE": "PHONE",
                    "lblSERVICEAREA": "SERVICE AREA",
                    "lblSERVICEDESCRIPTION": "SERVICE DESCRIPTION",
                    "lblSERVICESTATUS": "SERVICE STATUS",
                    "lblSRID": "SR ID",
                    "lblTECHNICIANID": "TECHNICIAN ID",
                    "lblmaterialsused": "Materials Used",
                    "lblservicenotes": "Service Notes",
                    "lbltasksperformed": "Tasks Performed"
                }, {
                    "lblADDRESS": "ADDRESS",
                    "lblCITY": "CITY",
                    "lblCUSTOMERNAME": "CUSTOMER NAME",
                    "lblEMAILID": "EMAIL ID",
                    "lblLOCATIONID": "LOCATION ID",
                    "lblPESTCONTROLTYPEID": "PEST CONTROL TYPE ID",
                    "lblPHONE": "PHONE",
                    "lblSERVICEAREA": "SERVICE AREA",
                    "lblSERVICEDESCRIPTION": "SERVICE DESCRIPTION",
                    "lblSERVICESTATUS": "SERVICE STATUS",
                    "lblSRID": "SR ID",
                    "lblTECHNICIANID": "TECHNICIAN ID",
                    "lblmaterialsused": "Materials Used",
                    "lblservicenotes": "Service Notes",
                    "lbltasksperformed": "Tasks Performed"
                }, {
                    "lblADDRESS": "ADDRESS",
                    "lblCITY": "CITY",
                    "lblCUSTOMERNAME": "CUSTOMER NAME",
                    "lblEMAILID": "EMAIL ID",
                    "lblLOCATIONID": "LOCATION ID",
                    "lblPESTCONTROLTYPEID": "PEST CONTROL TYPE ID",
                    "lblPHONE": "PHONE",
                    "lblSERVICEAREA": "SERVICE AREA",
                    "lblSERVICEDESCRIPTION": "SERVICE DESCRIPTION",
                    "lblSERVICESTATUS": "SERVICE STATUS",
                    "lblSRID": "SR ID",
                    "lblTECHNICIANID": "TECHNICIAN ID",
                    "lblmaterialsused": "Materials Used",
                    "lblservicenotes": "Service Notes",
                    "lbltasksperformed": "Tasks Performed"
                }, {
                    "lblADDRESS": "ADDRESS",
                    "lblCITY": "CITY",
                    "lblCUSTOMERNAME": "CUSTOMER NAME",
                    "lblEMAILID": "EMAIL ID",
                    "lblLOCATIONID": "LOCATION ID",
                    "lblPESTCONTROLTYPEID": "PEST CONTROL TYPE ID",
                    "lblPHONE": "PHONE",
                    "lblSERVICEAREA": "SERVICE AREA",
                    "lblSERVICEDESCRIPTION": "SERVICE DESCRIPTION",
                    "lblSERVICESTATUS": "SERVICE STATUS",
                    "lblSRID": "SR ID",
                    "lblTECHNICIANID": "TECHNICIAN ID",
                    "lblmaterialsused": "Materials Used",
                    "lblservicenotes": "Service Notes",
                    "lbltasksperformed": "Tasks Performed"
                }, {
                    "lblADDRESS": "ADDRESS",
                    "lblCITY": "CITY",
                    "lblCUSTOMERNAME": "CUSTOMER NAME",
                    "lblEMAILID": "EMAIL ID",
                    "lblLOCATIONID": "LOCATION ID",
                    "lblPESTCONTROLTYPEID": "PEST CONTROL TYPE ID",
                    "lblPHONE": "PHONE",
                    "lblSERVICEAREA": "SERVICE AREA",
                    "lblSERVICEDESCRIPTION": "SERVICE DESCRIPTION",
                    "lblSERVICESTATUS": "SERVICE STATUS",
                    "lblSRID": "SR ID",
                    "lblTECHNICIANID": "TECHNICIAN ID",
                    "lblmaterialsused": "Materials Used",
                    "lblservicenotes": "Service Notes",
                    "lbltasksperformed": "Tasks Performed"
                }, {
                    "lblADDRESS": "ADDRESS",
                    "lblCITY": "CITY",
                    "lblCUSTOMERNAME": "CUSTOMER NAME",
                    "lblEMAILID": "EMAIL ID",
                    "lblLOCATIONID": "LOCATION ID",
                    "lblPESTCONTROLTYPEID": "PEST CONTROL TYPE ID",
                    "lblPHONE": "PHONE",
                    "lblSERVICEAREA": "SERVICE AREA",
                    "lblSERVICEDESCRIPTION": "SERVICE DESCRIPTION",
                    "lblSERVICESTATUS": "SERVICE STATUS",
                    "lblSRID": "SR ID",
                    "lblTECHNICIANID": "TECHNICIAN ID",
                    "lblmaterialsused": "Materials Used",
                    "lblservicenotes": "Service Notes",
                    "lbltasksperformed": "Tasks Performed"
                }, {
                    "lblADDRESS": "ADDRESS",
                    "lblCITY": "CITY",
                    "lblCUSTOMERNAME": "CUSTOMER NAME",
                    "lblEMAILID": "EMAIL ID",
                    "lblLOCATIONID": "LOCATION ID",
                    "lblPESTCONTROLTYPEID": "PEST CONTROL TYPE ID",
                    "lblPHONE": "PHONE",
                    "lblSERVICEAREA": "SERVICE AREA",
                    "lblSERVICEDESCRIPTION": "SERVICE DESCRIPTION",
                    "lblSERVICESTATUS": "SERVICE STATUS",
                    "lblSRID": "SR ID",
                    "lblTECHNICIANID": "TECHNICIAN ID",
                    "lblmaterialsused": "Materials Used",
                    "lblservicenotes": "Service Notes",
                    "lbltasksperformed": "Tasks Performed"
                }],
                "groupCells": false,
                "height": "240dp",
                "id": "Segment0cf06365cb65444",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "FBox0a1238de6de8c46",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "lblADDRESS": "lblADDRESS",
                    "lblCITY": "lblCITY",
                    "lblCUSTOMERNAME": "lblCUSTOMERNAME",
                    "lblEMAILID": "lblEMAILID",
                    "lblLOCATIONID": "lblLOCATIONID",
                    "lblPESTCONTROLTYPEID": "lblPESTCONTROLTYPEID",
                    "lblPHONE": "lblPHONE",
                    "lblSERVICEAREA": "lblSERVICEAREA",
                    "lblSERVICEDESCRIPTION": "lblSERVICEDESCRIPTION",
                    "lblSERVICESTATUS": "lblSERVICESTATUS",
                    "lblSRID": "lblSRID",
                    "lblTECHNICIANID": "lblTECHNICIANID",
                    "lblmaterialsused": "lblmaterialsused",
                    "lblservicenotes": "lblservicenotes",
                    "lbltasksperformed": "lbltasksperformed"
                },
                "width": "100%",
                "appName": "RentokilTechician"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(Segment0cf06365cb65444);
        };
        return [{
            "addWidgets": addWidgetsForm2,
            "enabledForIdleTimeout": false,
            "id": "Form2",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "RentokilTechician",
            "preShow": function(eventobject) {
                controller.AS_Form_d5c050654215477a8686fe2a1ff43556(eventobject);
                voltmx.visualizer.syncComponentInstanceDataCache(eventobject);
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});