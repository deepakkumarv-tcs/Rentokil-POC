define("userForm2Controller", {
    //Type your controller code here 
});
define("Form2ControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_d5c050654215477a8686fe2a1ff43556: function AS_Form_d5c050654215477a8686fe2a1ff43556(eventobject) {
        var self = this;

        function SHOW_ALERT_d4cdfa41d92c48fc9de3d2d11407ba70_True() {}

        function INVOKE_ASYNC_SERVICE_h5b809fbe08740489adeaef215d50649_Callback(status, rentokil_db_service_request_trx_get) {
            voltmx.application.dismissLoadingScreen();
            if (rentokil_db_service_request_trx_get.opstatus == 0) {
                var tempCollection2406 = [];
                var tempData9206 = rentokil_db_service_request_trx_get.service_request_trx;
                for (var each6937 in tempData9206) {
                    var shouldShow = typeof tempData9206[each6937]["x_0024FILES"] !== 'undefined' && tempData9206[each6937]["x_0024FILES"] && tempData9206[each6937]["x_0024FILES"].length > 0
                    tempCollection2406.push({
                        "lblSRID": {
                            "text": voltmx.visualizer.toString(tempData9206[each6937]["SR_ID"])
                        },
                        "lblCUSTOMERNAME": {
                            "text": tempData9206[each6937]["CUSTOMER_NAME"]
                        },
                        "lblEMAILID": {
                            "text": tempData9206[each6937]["EMAIL_ID"]
                        },
                        "lblPHONE": {
                            "text": tempData9206[each6937]["PHONE"]
                        },
                        "lblSERVICEAREA": {
                            "text": tempData9206[each6937]["SERVICE_AREA"]
                        },
                        "lblPESTCONTROLTYPEID": {
                            "text": voltmx.visualizer.toString(tempData9206[each6937]["PEST_CONTROL_TYPE_ID"])
                        },
                        "lblTECHNICIANID": {
                            "text": voltmx.visualizer.toString(tempData9206[each6937]["TECHNICIAN_ID"])
                        },
                        "lblADDRESS": {
                            "text": tempData9206[each6937]["ADDRESS"]
                        },
                        "lblLOCATIONID": {
                            "text": voltmx.visualizer.toString(tempData9206[each6937]["LOCATION_ID"])
                        },
                        "lblCITY": {
                            "text": tempData9206[each6937]["CITY"]
                        },
                        "lblSERVICEDESCRIPTION": {
                            "text": tempData9206[each6937]["SERVICE_DESCRIPTION"]
                        },
                        "lblSERVICESTATUS": {
                            "text": tempData9206[each6937]["SERVICE_STATUS"]
                        },
                        "lbltasksperformed": {
                            "text": tempData9206[each6937]["tasks_performed"]
                        },
                        "lblservicenotes": {
                            "text": tempData9206[each6937]["service_notes"]
                        },
                        "lblmaterialsused": {
                            "text": tempData9206[each6937]["materials_used"]
                        },
                    });
                }
                self.view.Segment0cf06365cb65444.setData(tempCollection2406);
            } else {
                function SHOW_ALERT_d4cdfa41d92c48fc9de3d2d11407ba70_Callback() {
                    SHOW_ALERT_d4cdfa41d92c48fc9de3d2d11407ba70_True();
                }
                voltmx.ui.Alert({
                    "alertType": constants.ALERT_TYPE_INFO,
                    "alertTitle": null,
                    "yesLabel": null,
                    "noLabel": null,
                    "alertIcon": null,
                    "message": "Data fetch failed! Please try again later.",
                    "alertHandler": SHOW_ALERT_d4cdfa41d92c48fc9de3d2d11407ba70_Callback
                }, {
                    "iconPosition": constants.ALERT_ICON_POSITION_LEFT
                });
            }
        }
        voltmx.application.showLoadingScreen(null, null, constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
        if (rentokil_db_service_request_trx_get_inputparam == undefined) {
            var rentokil_db_service_request_trx_get_inputparam = {};
        }
        rentokil_db_service_request_trx_get_inputparam["serviceID"] = "db_integration_service$rentokil_db_service_request_trx_get";
        var rentokil_db_service_request_trx_get_httpheaders = {};
        rentokil_db_service_request_trx_get_inputparam["httpheaders"] = rentokil_db_service_request_trx_get_httpheaders;
        var rentokil_db_service_request_trx_get_httpconfigs = {};
        rentokil_db_service_request_trx_get_inputparam["httpconfig"] = rentokil_db_service_request_trx_get_httpconfigs;
        db_integration_service$rentokil_db_service_request_trx_get = mfintegrationsecureinvokerasync(rentokil_db_service_request_trx_get_inputparam, "db_integration_service", "rentokil_db_service_request_trx_get", INVOKE_ASYNC_SERVICE_h5b809fbe08740489adeaef215d50649_Callback);
    }
});
define("Form2Controller", ["userForm2Controller", "Form2ControllerActions"], function() {
    var controller = require("userForm2Controller");
    var controllerActions = ["Form2ControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
