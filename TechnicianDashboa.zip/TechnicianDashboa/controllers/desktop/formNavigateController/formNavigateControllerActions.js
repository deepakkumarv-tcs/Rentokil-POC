define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** init defined for formNavigate **/
    AS_Form_d24c1b3d46d3448e8227225935b1ebee: function AS_Form_d24c1b3d46d3448e8227225935b1ebee(eventobject) {
        var self = this;
        console.log(this);
        debugger;
    }
});