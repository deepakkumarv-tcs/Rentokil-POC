define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** init defined for technicianDashboard **/
    AS_Form_e3bf1d46b930401abcf16866217b40b5: function AS_Form_e3bf1d46b930401abcf16866217b40b5(eventobject) {
        var self = this;
        this.invokeService();
    },
    /** onClick defined for btnJobDetails **/
    AS_Button_ec955559a41e49ac9a84ee32534620ce: function AS_Button_ec955559a41e49ac9a84ee32534620ce(eventobject) {
        var self = this;
        console.log(this);
        debugger;
    }
});