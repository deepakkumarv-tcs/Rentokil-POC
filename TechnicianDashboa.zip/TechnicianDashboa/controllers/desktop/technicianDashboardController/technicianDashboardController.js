define({ 

 //Type your controller code here 
  invokeService: function(){
    var self = this;
    if (rentokil_db_service_request_trx_get_inputparam == undefined) {
        var rentokil_db_service_request_trx_get_inputparam = {};
    }
    rentokil_db_service_request_trx_get_inputparam["serviceID"] = "db_integration_service$rentokil_db_service_request_trx_get";
    //rentokil_db_service_request_trx_get_inputparam["$filter"] = "SERVICE_STATUS eq Assigned";
    //rentokil_db_service_request_trx_get_inputparam["$filter"] = "SERVICE_STATUS eq 'In Progress'";
    var rentokil_db_service_request_trx_get_httpheaders = {};
    rentokil_db_service_request_trx_get_inputparam["httpheaders"] = rentokil_db_service_request_trx_get_httpheaders;
    var rentokil_db_service_request_trx_get_httpconfigs = {};
    rentokil_db_service_request_trx_get_inputparam["httpconfig"] = rentokil_db_service_request_trx_get_httpconfigs;
    db_integration_service$rentokil_db_service_request_trx_get = mfintegrationsecureinvokerasync(rentokil_db_service_request_trx_get_inputparam, "db_integration_service", "rentokil_db_service_request_trx_get", this.callback);
  },
  callback: function (status, resp) {
    debugger;
    
    const response = resp.service_request_trx;
    if(resp && response.length > 0) {
      const assignedJobs = response.filter(card=>card.SERVICE_STATUS === "Assigned");
      const inProgressJobs = response.filter(card=>card.SERVICE_STATUS === "In Progress");
      const assignedCardsWrapper = this.view.flxScrollContainer.flxPageContainer.flxMain.flxRightbar.flxAssignedWrapper;
      const onGoingCardsWrapper = this.view.flxScrollContainer.flxPageContainer.flxMain.flxRightbar.flxOngoingWrapper;
      assignedJobs.forEach((card, index)=>{
        let jobCard = assignedCardsWrapper.jobCard.clone(`jobCard_${index}_`);
        jobCard[`jobCard_${index}_address`].text = card.ADDRESS + " " + card.CITY;
        jobCard[`jobCard_${index}_cardName`].text = card.SERVICE_DESCRIPTION.substring(0,32);
        jobCard[`jobCard_${index}_labelAssigned`].text = card.SERVICE_STATUS;
        jobCard[`jobCard_${index}_lblReqId`].text = card.SR_ID;
        //Add concat of date & time mapping
        jobCard.setVisibility(true);
		assignedCardsWrapper.add(jobCard);
      });
      
      inProgressJobs.forEach((card, index)=>{
        let jobCard = onGoingCardsWrapper.jobCardOnGoing.clone(`jobCard_${index}_`);
        jobCard[`jobCard_${index}_addressOngoing`].text = card.ADDRESS + " " + card.CITY;
        jobCard[`jobCard_${index}_cardNameOngoing`].text = card.SERVICE_DESCRIPTION.substring(0,32);
        jobCard[`jobCard_${index}_labelOnGoing`].text = card.SERVICE_STATUS;
        jobCard[`jobCard_${index}_lblReqIdOngoing`].text = card.SR_ID;
        //Add concat of date & time mapping
		onGoingCardsWrapper.add(jobCard);
        jobCard.setVisibility(true);
      })
    }
  }

 });