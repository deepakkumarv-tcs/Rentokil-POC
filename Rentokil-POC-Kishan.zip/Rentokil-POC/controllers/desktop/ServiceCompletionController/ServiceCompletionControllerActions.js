define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0c9f2a4cb4f8a41 **/
    AS_Button_ibb0dafec9634ffe9b93be10e14b4f8b: function AS_Button_ibb0dafec9634ffe9b93be10e14b4f8b(eventobject) {
        var self = this;

        function INVOKE_SERVICE_b29689b84b7744a38456771b026f84f1_Callback(status, rentokil_db_service_request_trx_update) {}
        if (rentokil_db_service_request_trx_update_inputparam == undefined) {
            var rentokil_db_service_request_trx_update_inputparam = {};
        }
        rentokil_db_service_request_trx_update_inputparam["serviceID"] = "NewService$rentokil_db_service_request_trx_update";
        var rentokil_db_service_request_trx_update_httpheaders = {};
        rentokil_db_service_request_trx_update_inputparam["httpheaders"] = rentokil_db_service_request_trx_update_httpheaders;
        var rentokil_db_service_request_trx_update_httpconfigs = {};
        rentokil_db_service_request_trx_update_inputparam["httpconfig"] = rentokil_db_service_request_trx_update_httpconfigs;
        NewService$rentokil_db_service_request_trx_update = mfintegrationsecureinvokerasync(rentokil_db_service_request_trx_update_inputparam, "NewService", "rentokil_db_service_request_trx_update", INVOKE_SERVICE_b29689b84b7744a38456771b026f84f1_Callback);
    },
    /** preShow defined for ServiceCompletion **/
    AS_Form_e9c8b7107cc74c2a8324377007db74d0: function AS_Form_e9c8b7107cc74c2a8324377007db74d0(eventobject) {
        var self = this;

        function INVOKE_SERVICE_h05c33e5f96542bea58fca1818897d4a_Callback(status, rentokil_db_service_request_trx_get) {}
        if (rentokil_db_service_request_trx_get_inputparam == undefined) {
            var rentokil_db_service_request_trx_get_inputparam = {};
        }
        rentokil_db_service_request_trx_get_inputparam["serviceID"] = "NewService$rentokil_db_service_request_trx_get";
        var rentokil_db_service_request_trx_get_httpheaders = {};
        rentokil_db_service_request_trx_get_inputparam["httpheaders"] = rentokil_db_service_request_trx_get_httpheaders;
        var rentokil_db_service_request_trx_get_httpconfigs = {};
        rentokil_db_service_request_trx_get_inputparam["httpconfig"] = rentokil_db_service_request_trx_get_httpconfigs;
        NewService$rentokil_db_service_request_trx_get = mfintegrationsecureinvokerasync(rentokil_db_service_request_trx_get_inputparam, "NewService", "rentokil_db_service_request_trx_get", INVOKE_SERVICE_h05c33e5f96542bea58fca1818897d4a_Callback);
    }
});