define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for ButtonSubmit **/
    AS_Button_b6a402a0b18e4b1a9cece487bb9caec3: function AS_Button_b6a402a0b18e4b1a9cece487bb9caec3(eventobject) {
        var self = this;

        function INVOKE_SERVICE_g09e364c51a84b0ea37aa3e33da002c4_Callback(status, rentokil_db_service_request_trx_create) {}
        if (rentokil_db_service_request_trx_create_inputparam == undefined) {
            var rentokil_db_service_request_trx_create_inputparam = {};
        }
        rentokil_db_service_request_trx_create_inputparam["serviceID"] = "NewService$rentokil_db_service_request_trx_create";
        rentokil_db_service_request_trx_create_inputparam["customer_name"] = self.view.TextFieldCstFullName.text;
        rentokil_db_service_request_trx_create_inputparam["address"] = self.view.TextFieldCstHouse.text;
        rentokil_db_service_request_trx_create_inputparam["city"] = self.view.TextFieldCstCity.text;
        rentokil_db_service_request_trx_create_inputparam["PIN"] = self.view.TextFieldPincode.text;
        rentokil_db_service_request_trx_create_inputparam["service_description"] = self.view.TextAreaDes.text;
        rentokil_db_service_request_trx_create_inputparam["email_id"] = self.view.TextFieldCstEmail.text;
        rentokil_db_service_request_trx_create_inputparam["phone"] = self.view.TextFieldCstContactNumber.text;
        rentokil_db_service_request_trx_create_inputparam["pest_control_type_name"] = self.view.ListBoxServiceType.masterData[0][1];
        rentokil_db_service_request_trx_create_inputparam["State"] = self.view.ListBoxState.masterData[0][1];
        rentokil_db_service_request_trx_create_inputparam["Country"] = self.view.ListBoxCountry.masterData[0][1];
        rentokil_db_service_request_trx_create_inputparam["service_area"] = self.view.TextFieldCstAppartment.text;
        var rentokil_db_service_request_trx_create_httpheaders = {};
        rentokil_db_service_request_trx_create_inputparam["httpheaders"] = rentokil_db_service_request_trx_create_httpheaders;
        var rentokil_db_service_request_trx_create_httpconfigs = {};
        rentokil_db_service_request_trx_create_inputparam["httpconfig"] = rentokil_db_service_request_trx_create_httpconfigs;
        NewService$rentokil_db_service_request_trx_create = mfintegrationsecureinvokerasync(rentokil_db_service_request_trx_create_inputparam, "NewService", "rentokil_db_service_request_trx_create", INVOKE_SERVICE_g09e364c51a84b0ea37aa3e33da002c4_Callback);
    },
    /** onMapping defined for serviceBooking **/
    AS_Form_ed89d74614594b6a8913d5f33e048e3f: function AS_Form_ed89d74614594b6a8913d5f33e048e3f(eventobject) {
        var self = this;
    },
    /** onSelection defined for ListBoxState **/
    AS_ListBox_c1d0c317bc4a4b1ba0f2c8828f1142e0: function AS_ListBox_c1d0c317bc4a4b1ba0f2c8828f1142e0(eventobject) {
        var self = this;
        var customerState = txtCustomerState;
    },
    /** onSelection defined for ListBoxServiceType **/
    AS_ListBox_d8c5504a6d234e84bb6aaf52197a017d: function AS_ListBox_d8c5504a6d234e84bb6aaf52197a017d(eventobject) {
        var self = this;
        var customerServiceType = txtCustomerServiceType;
    },
    /** onSelection defined for ListBoxCountry **/
    AS_ListBox_if322784be1342a69ebd2e6d196c081d: function AS_ListBox_if322784be1342a69ebd2e6d196c081d(eventobject) {
        var self = this;
        var customerCountry = txtCustomerCountry;
    },
    /** onTextChange defined for TextAreaDes **/
    AS_TextArea_a77414cf98934c37aaf36e4a6a3ba567: function AS_TextArea_a77414cf98934c37aaf36e4a6a3ba567(eventobject) {
        var self = this;
        var customerServiceDesc = txtCustomerServiceDesc;
    },
    /** onTextChange defined for TextFieldCstAppartment **/
    AS_TextField_b74d8e7a44624fa3ade26e8853fe190f: function AS_TextField_b74d8e7a44624fa3ade26e8853fe190f(eventobject, changedtext) {
        var self = this;
        var customerLocation = txtCustomerLocation;
    },
    /** onTextChange defined for TextFieldCstCity **/
    AS_TextField_d11cb893535441b8a9e42d9c469bf818: function AS_TextField_d11cb893535441b8a9e42d9c469bf818(eventobject, changedtext) {
        var self = this;
        var customerCity = txtCustomerCity;
    },
    /** onTextChange defined for TextFieldCstEmail **/
    AS_TextField_d7a6b62a608e4c2f8755b3f4581d61c3: function AS_TextField_d7a6b62a608e4c2f8755b3f4581d61c3(eventobject, changedtext) {
        var self = this;
        var customerEmail = txtCustomerEmail;
    },
    /** onTextChange defined for TextFieldCstHouse **/
    AS_TextField_d830be81197948b6827178c80534b2bc: function AS_TextField_d830be81197948b6827178c80534b2bc(eventobject, changedtext) {
        var self = this;
        var customerAddress = txtCustomerAddress;
    },
    /** onTextChange defined for TextFieldCstFullName **/
    AS_TextField_e18ddf2f6ea34469bdaa3bf184b9d791: function AS_TextField_e18ddf2f6ea34469bdaa3bf184b9d791(eventobject, changedtext) {
        var self = this;
        var customerName = txtCustomerName;
    },
    /** onTextChange defined for TextFieldCstContactNumber **/
    AS_TextField_g0f57b4e473e4753a984e2bd8729f38b: function AS_TextField_g0f57b4e473e4753a984e2bd8729f38b(eventobject, changedtext) {
        var self = this;
        var customerContactNumber = txtCustomerContactNumber;
    },
    /** onTextChange defined for TextFieldPincode **/
    AS_TextField_j291eac5a31546ca94eeb03c529c3ee0: function AS_TextField_j291eac5a31546ca94eeb03c529c3ee0(eventobject, changedtext) {
        var self = this;
        var customerPincode = txtCustomerPincode;
    }
});