define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** init defined for frmHome **/
    AS_Form_g8dbbdd9f443478e9b993ebbee64758a: function AS_Form_g8dbbdd9f443478e9b993ebbee64758a(eventobject) {
        var self = this;
        /*if(this.navigationContext && this.navigationContext.ServiceID_text) {
  var service_id = this.navigationContext.ServiceID_text;
  this.fetchServiceData(service_id);
}*/
        this.fetchServiceData(1);
    }
});