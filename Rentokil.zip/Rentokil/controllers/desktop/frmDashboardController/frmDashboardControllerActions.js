define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onBreakpointChange defined for frmDashboard **/
    AS_Form_hcaeba69a7c64bc39762419bb6299f7b: function AS_Form_hcaeba69a7c64bc39762419bb6299f7b(eventobject, breakpoint) {
        var self = this;
    }
});